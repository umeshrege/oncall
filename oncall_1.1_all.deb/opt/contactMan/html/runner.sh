#!/bin/sh


while [ true ]; do
sleep 300;
`which python` /opt/contactMan/html/TableEquilizer.py; 
done
