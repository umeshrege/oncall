#!/usr/bin/python

import Cookie
import cgi
import cgitb
import os

cookie = Cookie.SimpleCookie()
ifcookie = os.environ.get('HTTP_COOKIE')

if not ifcookie:
	print """Content-Type: text/html\n\n\r
<html>
<head>
	<title>Flipkart OnCall Search</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
	<div id="loghead">
	</div>
	<div id="header">
		<p><a href="index.py">Flipkart OnCall Search</a></p>
	</div>
	<div id="titlenav">
	<form action="login.py" method="POST" style="
	    color: white;
	    text-align: right;
	    font-size: 1.5em;
	    margin-right: 20px;
	    font-weight: bold;
	">
		<font size="2"> Username: </font>
		<input autocomplete="off" name="empname" class="biginput" id="autocomplete" autofocus="" type="text" required="">
    	<font size="2"> Password: </font>
		<input autocomplete="off" name="emppass" class="biginput" id="autocomplete" autofocus="" type="password" required="">    
		<input value="Submit" type="submit"><br>
	</form>
	</div>
</div>

<div class="search">
<h1>Employee Search</h1>
	<div id="searchfield">
	<form action="searchme.py" method="POST">
		<font size="2"> Name: </font>
		<input autocomplete="off" name="empsearch" class="biginput" id="autocomplete" autofocus="" type="text" required><br><br>
		<input type="radio" name="typesearch" value="emp_search" checked="checked">Employee Search
		<input type="radio" name="typesearch" value="oncall_search">On-Call Search
 		<br>
		<br>
		<input value="Submit" type="submit"><br>
	</form>
	</div>
</div>
</body>
</html>
"""
else:
        cookie.load(ifcookie)
        username = cookie['username'].value
        name = cookie['name'].value
	if len(username) > 0 and len(name) > 0:
		print """Content-Type: text/html\n\n\r
<html>
<head>
        <title>Flipkart OnCall Search</title>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
        <div id="loghead">
        </div>
        <div id="header">
                <p><a href="index.py">Flipkart OnCall Search</a></p>
        </div>
        <div id="titlenav">
		<p style="color: white;">%s<form action="logout.py" method="POST"><input value="logout" type="submit"></form></p>
        </div>
</div>

<div class="search">
<h1>Employee Search</h1>
        <div id="searchfield">
        <form action="searchme.py" method="POST">
                <font size="2"> Name: </font>
                <input autocomplete="off" name="empsearch" class="biginput" id="autocomplete" autofocus="" type="text" required><br><br>
                <input type="radio" name="typesearch" value="emp_search" checked="checked">Employee Search
                <input type="radio" name="typesearch" value="oncall_search">On-Call Search
                <br>
                <br>
                <input value="Submit" type="submit"><br>
        </form>
        </div>
</div>
</body>
</html>
""" %(username)
	else:
		print """Content-Type: text/html\n\n\r
<html>
<head>
        <title>Flipkart OnCall Search</title>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
        <div id="loghead">
        </div>
        <div id="header">
                <p><a href="index.py">Flipkart OnCall Search</a></p>
        </div>
        <div id="titlenav">
        <form action="login.py" method="POST" style="
            color: white;
            text-align: right;
            font-size: 1.5em;
            margin-right: 20px;
            font-weight: bold;
        ">
                <font size="2"> Username: </font>
                <input autocomplete="off" name="empname" class="biginput" id="autocomplete" autofocus="" type="text" required="">
        <font size="2"> Password: </font>
                <input autocomplete="off" name="emppass" class="biginput" id="autocomplete" autofocus="" type="password" required="">    
                <input value="Submit" type="submit"><br>
        </form>
        </div>
</div>

<div class="search">
<h1>Employee Search</h1>
        <div id="searchfield">
        <form action="searchme.py" method="POST">
                <font size="2"> Name: </font>
                <input autocomplete="off" name="empsearch" class="biginput" id="autocomplete" autofocus="" type="text" required><br><br>
                <input type="radio" name="typesearch" value="emp_search" checked="checked">Employee Search
                <input type="radio" name="typesearch" value="oncall_search">On-Call Search
                <br>
                <br>
                <input value="Submit" type="submit"><br>
        </form>
        </div>
</div>
</body>
</html>
"""
