#!/usr/bin/python

import Cookie
import os
import cgi
import cgitb
import time
from random import randint

#cookie = Cookie.SimpleCookie()
#cookie['lastvisit'] = str(time.time())

#print cookie
print """Content-Type: text/html\n\n\r
<html>
<head>
	<title>Flipkart Tech YellowPage</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
	<div id="loghead">
	<form action="login.py" method="POST">

	</form>
	</div>
	<div id="header">
		<p><a href="index.py">Flipkart Tech YellowPage</a></p>
	</div>
	<div id="titlenav">
		<ul>
			<li><a href="newregi.py">Register</a></li>
			<li><a href="update.py">Update</a></li>
		</ul>
	</div>
</div>

<div class="search">
<h1>Employee Search</h1>
	<div id="searchfield">
	<form action="searchme.py" method="POST">
		<font size="2"> Name: </font>
		<input autocomplete="off" name="empsearch" class="biginput" id="autocomplete" autofocus="" type="text" required><br><br>
		<input type="radio" name="typesearch" value="emp_search" checked="checked">Employee Search
		<input type="radio" name="typesearch" value="oncall_search">On-Call Search
 		<br>
		<br>
		<input value="Submit" type="submit"><br>
	</form>
	</div>
</div>
</body>
</html>
"""
