#!/usr/bin/python

import cgi
import cgitb
import MySQLdb


dat = cgi.FieldStorage()

#name = str('%') + "ricky" + str('%')
#seatype ="emp_search"

seatype = dat.getvalue('typesearch')

mydb = MySQLdb.connect('localhost', 'root', 'd3fault', 'contact')
mycurs = mydb.cursor()

print """Content-Type: text/html\n\n\r
<html>
<head>
	<title>Flipkart Tech YellowPage</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
	<div id="header">
		<p><a href="index.py">Flipkart Tech YellowPage</a></p>
	</div>
	<div id="titlenav">
		<ul>
		</ul>
	</div>
</div>

<div class="search">
<div class="sresult"> 
"""
if seatype == 'emp_search':
	name = dat.getvalue('empsearch')
	quer = "select name, team, email_id, phnum from contactman where name like " +str('\'%')+name+str('%\'')
	mycurs.execute(quer)
	myout = mycurs.fetchall()
	if len(myout) > 0:
		print """<table class='mycount'>
			<thead>
			<tr>
			<th>Name</th>   
			<th>Team</th>   
			<th>Email Id</th>       
			<th>Phone Number</th>   
			</tr>
			</thead>
			"""
		for i in range(len(myout)):
			print "<tbody>"
			print "<tr>"
			print "<td>%s</td>" %myout[i][0]
			if myout[i][1] == None:
				print "<td>None</td>"
			else:
				print "<td>%s</td>" %myout[i][1].lower()
			print "<td>%s</td>" %myout[i][2]
			print "<td>%s</td>" %myout[i][3]
			print "</tr>"
			print "</tbody>"
	else:
		print "<h2>Our database does not contain a user by the name "+str(name)+ "</h2>"
elif seatype == 'oncall_search':
	name = dat.getvalue('empsearch')
	quer = "select name, email_id, phnum, p_oncall, s_oncall from contactman where team='%s' and (p_oncall='y' or s_oncall='y')" %(name)
	mycurs.execute(quer)
	myout = mycurs.fetchall()
	if len(myout) > 0:
		print """<table class='mycount'>
			<thead>
			<tr>
			<th>Name</th>   
			<th>Email Id</th>       
			<th>Phone Number</th>   
			<th>On-Call</th>   
			</tr>
			</thead>
			"""
		for i in range(len(myout)):
			print "<tbody>"
			print "<tr>"
			print "<td>%s</td>" %myout[i][0]
			print "<td>%s</td>" %myout[i][1]
			print "<td>%s</td>" %myout[i][2]
			if myout[i][3] == "y":
				print "<td>Primary</td>" 
			if myout[i][4] == "y":
				print "<td>Secondary</td>" 
			print "</tr'>"
			print "</tbody>"
	else:
		print "<h2>We haven't on-boarded a team by the name '%s' <br style='text-align: center'> or <br>there is no designated primary/secondary oncall</h2>" %(name)

print"""
</div>
</div>
</body>
</html>
"""

mydb.close()
