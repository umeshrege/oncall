#!/usr/bin/python

import cgi
import cgitb
import MySQLdb


dat = cgi.FieldStorage()

#name = str('%') + "ricky" + str('%')
#seatype ="emp_search"

seatype = dat.getvalue('typesearch')

mydb = MySQLdb.connect('localhost', 'root', 'd3fault', 'contact')
mycurs = mydb.cursor()

print """Content-Type: text/html\n\n\r
<html>
<head>
	<title>Flipkart Tech YellowPage</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
	<div id="header">
		<p><a href="index.py">Flipkart Tech YellowPage</a></p>
	</div>
	<div id="titlenav">
		<ul>
		</ul>
	</div>
</div>

<div class="search">
<div class="sresult"> 
"""
if seatype == 'emp_search':
	name = dat.getvalue('empsearch')
	quer = "select name, team, email_id, phnum, manager, manid from contactman where name like " +str('\'%')+name+str('%\'')
	mycurs.execute(quer)
	myout = mycurs.fetchall()
	if len(myout) > 0:
                print """<p id='restitle' style="margin-left: 3px; color: red;"> Search result for the user "%s"<br>
		Note: Click on the manager's name to get his/her details.
		</p>""" %(name)
                for i in range(len(myout)):
                        print "<form><fieldset>"
                        print "<legend>"+str(myout[i][0])+"</legend>"
                        print "<table>"
                        print "<tbody>"
                        print "<tr>"
                        print "<td>Name</td>"
                        print "<td>"+str(myout[i][0])+"</td>"
                        print "</tr>"
                        print "<tr>"
                        print "<td>Team</td>"
                        print "<td>"+str(myout[i][1])+"</td>"
                        print "</tr>"
                        print "<tr>"
                        print "<td>Email Address</td>"
                        print "<td>"+str(myout[i][2])+"</td>"
                        print "</tr>"
                        print "<tr>"
                        print "<td>Phone Number</td>"
                        print "<td>"+str(myout[i][3])+"</td>"
                        print "</tr>"
                        print "<tr>"
                        print "<td>Manager</td>"
                        print "<td>"+"<a href='searchme.py?empsearch="+str(myout[i][4])+"&typesearch=emp_search'>"+str(myout[i][4])+"</a></td>"
                        print "</tr>"
                        print "</tbody>"
                        print "</table>"
                        print "</form></fieldset>"
	else:
		print "<h2>Our database does not contain a user by the name "+str(name)+ "</h2>"
elif seatype == 'oncall_search':
	name = dat.getvalue('empsearch')
	quer = "select name, email_id, phnum, p_oncall, s_oncall from contactman where team='%s' and (p_oncall='y' or s_oncall='y')" %(name)
	mycurs.execute(quer)
	myout = mycurs.fetchall()
	if len(myout) > 0:
		print """<table class='mycount'>
			<thead>
			<tr>
			<th>Name</th>   
			<th>Email Id</th>       
			<th>Phone Number</th>   
			<th>On-Call</th>   
			</tr>
			</thead>
			"""
		for i in range(len(myout)):
			print "<tbody>"
			print "<tr>"
			print "<td>%s</td>" %myout[i][0]
			print "<td>%s</td>" %myout[i][1]
			print "<td>%s</td>" %myout[i][2]
			if myout[i][3] == "y":
				print "<td>Primary</td>" 
			if myout[i][4] == "y":
				print "<td>Secondary</td>" 
			print "</tr'>"
			print "</tbody>"
	else:
		print "<h2>We haven't on-boarded a team by the name '%s' <br style='text-align: center'> or <br>there is no designated primary/secondary oncall</h2>" %(name)

print"""
</div>
</div>
</body>
</html>
"""

mydb.close()
