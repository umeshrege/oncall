#!/usr/bin/python

import os
import Cookie

cookie = Cookie.SimpleCookie()
ifcookie = os.environ.get('HTTP_COOKIE')

if not ifcookie:
	print """Content-type: text/html\n\n\r

<html>
<head>
        <title>Flipkart Tech YellowPage</title>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<meta http-equiv="refresh" content="0; url=http://oncall.nm.flipkart.com" />
</head>
<body></body>
</html>
"""

else:
	print """Content-type: text/html\n\n\r

<html>
<head>
	<title>Flipkart Tech YellowPage</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
	<div id="header">
		<p><a href="index.py">Flipkart Tech YellowPage</a></p>
	</div>
	<div id="titlenav">
		<ul>
			<li></li>
		</ul>
	</div>
</div>

<div class="search">
<h1>Enter your details</h1>
	<div id="searchfield">
	<form action="conreg.py" method="POST">
		<font size="2"> EmpID: </font><input type="number"  name="empid" class="reginput" placeholder="12345" required><br><br>
		<font size="2">  Name: </font><input type="text"  name="name" class="reginput" placeholder="John Doe" required><br><br>
		<font size="2"> Email: </font><input type="email"  name="email" class="reginput" placeholder="john.doe@flipkart.com" required><br><br>
		<font size="2"> Phone: </font><input type="number"  name="phnum" class="reginput" maxlength="12" placeholder="Min 10 digits" required><br><br>
		<font size="2">  Team: </font><input type="text"  name="team" class="reginput" placeholder="Team"  required><br><br>
		<font size="2"> Primary On-call </font><input type="radio" name="oncall" value="pri-oncall">
		<font size="2"> Secondary On-call </font><input type="radio" name="oncall" value="sec-oncall">
 		<br>
		<br>
		<input value="Continue" type="submit"><br>
	</form>
	</div>
</div>
</body>
</html>

""" 
