#!/usr/bin/python

import cgi
import cgitb
import myapi
import MySQLdb

dat = cgi.FieldStorage()
empid = dat.getvalue('empid')
name = dat.getvalue('name')
email = dat.getvalue('email')
phnum = dat.getvalue('phnum')
team = dat.getvalue('team').lower()
if dat.getvalue('oncall') == "pri-oncall" :
	p_oncall = 'y'
	s_oncall = 'null'
elif dat.getvalue('oncall') == "sec-oncall": 
	p_oncall = 'null'
	s_oncall = 'y'
else:
	p_oncall = 'null'
	s_oncall = 'null'

mydb = MySQLdb.connect('localhost', 'root', 'd3fault', 'contact')
mycurs = mydb.cursor()

print"""Content-Type: text/html\n\n\r

<html>
<head>
        <title>Flipkart Tech YellowPage</title>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

<div class="title">
        <div id="header">
                <p><a href="index.py">Flipkart Tech YellowPage</a></p>
        </div>
        <div id="titlenav">
                <ul>
                        <li></li>
                </ul>
        </div>
</div>

	<div class="search">
"""

quer = 'select phnum, p_oncall, s_oncall from contactman where empid="%s"' %(empid)
mycurs.execute(quer)
mystat = mycurs.fetchall()

if mystat[0][1] == None:
	primcall = 'null'
else:
	primcall = mystat[0][1]
if mystat[0][2] == None:
	seccall = 'null'
else:
	seccall = mystat[0][2]


if phnum == mystat[0][0] and p_oncall == primcall and s_oncall == seccall:
	print "<p>There were no changes found. You data remains unchanged </p>"
else:
	if phnum != mystat[0][0]:
                phupda = 'update contactman set phnum="%s" where empid="%s"' %(phnum, empid)
                mycurs.execute(phupda)
                mydb.commit()
                print '<p>You phone number has been updated. Click here to go to the <a href="index.py">home</a> page</p>'
                mydb.close()
	else:
		pass
	
	if p_oncall != primcall:
        	seapcall = "select empid, name from contactman where team='%s' and p_oncall='y'" %(team)
		mycurs.execute(seapcall)
        	curpcall = mycurs.fetchall()
        	if  seccall == 'y' and p_oncall == 'y':
                	print "<p> You cannot be both primary and secondary on-call. Please ask your colleagues to take over the secondary oncall task </p>"
        	else:
                	if len(curpcall) > 0:
                        	quer = 'update contactman set p_oncall="y" where empid="%s"' %(empid)
                        	mycurs.execute(quer)
                        	mydb.commit()
                        	rmpcall = 'update contactman set p_oncall = NULL where empid="%s"' %(curpcall[0][0])
                        	mycurs.execute(rmpcall)
                        	mydb.commit()
                        	print '<p>You have been made the primary oncall - replacing %s</p>' %(curpcall[0][1])
                        	mydb.close()
               		else:
                        	quer = 'update contactman set p_oncall="y" where empid="%s"' %(empid)
                        	mycurs.execute(quer)
                        	mydb.commit()
                        	print '<p>%s --> You are now the primary on-call</p>' %(name)
                        	mydb.close()
	else:
		pass

        if s_oncall != seccall:
		conn = MySQLdb.connect('localhost', 'root', 'd3fault', 'contact')
		seccurse = conn.cursor()
                seascall = "select empid, name from contactman where team='%s' and s_oncall='y'" %(team)
                seccurse.execute(seascall)
                curscall = seccurse.fetchall()
                if  primcall == 'y' and s_oncall == 'y':
                        print "<p> You cannot be both primary and secondary on-call. Please ask your colleagues to take over the primary oncall task </p>"
                else:
                        if len(curscall) > 0:
                                quer = 'update contactman set s_oncall="y" where empid="%s"' %(empid)
                                seccurse.execute(quer)
                                conn.commit()
                                rmscall = 'update contactman set s_oncall = NULL where empid="%s"' %(curscall[0][0])
                                seccurse.execute(rmscall)
                                conn.commit()
                                print '<p>You have been made the secondary oncall - replacing %s</p>' %(curpcall[0][1])
                                conn.close()
                        else:
                                quer = 'update contactman set s_oncall="y" where empid="%s"' %(empid)
                                seccurse.execute(quer)
                                conn.commit()
                                print '<p>%s --> You are now the secondary on-call</p>' %(name)
                                conn.close()
	else:
		pass

print '<p>Click here to go to the <a href="index.py">home</a> page</p>'
print """
        </div>
</div>
</body>
</html>
"""
myapi.contactman()
